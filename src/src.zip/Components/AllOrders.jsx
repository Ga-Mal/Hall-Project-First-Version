import React from "react";
import { FiPrinter } from "react-icons/fi";

export const styleBtnStatus =
  "text-white px-2 py-1 text-[18px] rounded-xl cursor-pointer hover:scale-105 transition";

function AllOrders() {
  return (
    <>
      <div className="bg-gray-400 rounded-2xl shadow-lg p-6 flex flex-col gap-2 ">
        <div className="flex flex-col items-end gap-2 relative">
          {/* Print Button (Top Right) */}
          <button
            // onClick={() => handlePrint(order)}
            className="absolute top-4 right-4 text-(--primary-color) hover:scale-120 duration-200 cursor-pointer"
            title="Print Order">
            <FiPrinter size={20} />
          </button>

          {/* Header */}
          <div className="flex justify-between items-center border-b pb-3 border-white/10 mr-8">
            <div>
              <h2 className="font-bold text-lg"># ID</h2>
              <p className="text-sm opacity-70"> items </p>
            </div>

            {/* Status */}
            <span
              className={`px-3 py-1 rounded-full text-sm font-bold ${
                status.toLowerCase() === "pending"
                  ? "bg-yellow-500/20 text-yellow-600"
                  : ["paid", "delivered", "shipped", "processing"].includes(
                        status.toLowerCase(),
                      )
                    ? "bg-green-500/20 text-green-600"
                    : "bg-red-500/20 text-red-600"
              }`}>
              {status}
            </span>
          </div>

          {/* Products */}

          {/* Total */}
          <div className="flex justify-between font-bold text-lg mt-2">
            <span>Total</span>
            <span className="text-(--primary-color)">Total EGP</span>
          </div>

          {/* Customer Info */}
          <div className="bg-black/10 rounded-xl p-4 text-sm mt-3 border border-white/5 space-y-1">
            <p>
              <strong>Name:</strong> name
            </p>
            <p>
              <strong>Email:</strong> email
            </p>
            <p>
              <strong>Phone:</strong> phone
            </p>
            <p>
              <strong>Location:</strong> city{" "}
            </p>
            {/* {order.paymentMethod && <p><strong>Payment:</strong> {order.paymentMethod}</p>} */}
            <p>
              <strong>Payment:</strong> Payments{" "}
            </p>
          </div>

          {/* Actions */}
          <div className="flex gap-2 flex-wrap mt-4">
            <button
              // onClick={() => handleStatusChange(id, 'Processing')}
              className={`bg-green-600/20 text-green-500 border border-green-600/30${styleBtnStatus}   text-sm`}>
              Process
            </button>
            <button
              // onClick={() => handleStatusChange(id, 'Shipped')}
              className={`bg-blue-600/20 text-blue-500 border border-blue-600/30 ${styleBtnStatus} text-sm`}>
              Ship
            </button>
            <button
              // onClick={() => handleStatusChange(id, 'Delivered')}
              className={`bg-green-800/20 text-green-700 border border-green-800/30${styleBtnStatus}  text-sm`}>
              Deliver
            </button>
            <button
              // onClick={() => handleStatusChange(id, 'Cancelled')}
              className={`bg-red-600/20 text-red-500 border border-red-600/30 ${styleBtnStatus} text-sm`}>
              Cancel
            </button>
          </div>

          {/* Debug (remove later if mapping is perfect) */}
          {/* {typeof order.total === 'undefined' && typeof order.totalAmount === 'undefined' && (
              <p className="text-[9px] text-gray-500 mt-2 break-all">Debug: {Object.keys(order).join(", ")}</p>
            )} */}
        </div>
      </div>
    </>
  );
}

export default AllOrders;
